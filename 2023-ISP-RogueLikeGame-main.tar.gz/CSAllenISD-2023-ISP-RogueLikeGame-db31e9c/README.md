# 2023-ISP-RogueLikeGame

## Members

Product Manager: [aclassypotater](https://www.codermerlin.com/users/evan-bowerman/Digital%20Portfolio/index.html)

Project Manager: [ChrisC305446](https://www.codermerlin.com/users/christopher-carter/Digital%20Portfolio/index.html)

Quality Assurance Engineer: [someone1230](https://codermerlin.com/users/andrew-liu/Digital%20Portfolio/index.html)

Development Engineer: [Vereie](https://www.codermerlin.com/users/robert-brugger/Digital%20Portfolio/index.html)

A brief description of our ISP:
For our ISP we will be creating a rogue-like game. To create the rogue-like game we will be experimenting with the engine Godot. The languages we will use are Python and Godot engine GAP language. 
:)
